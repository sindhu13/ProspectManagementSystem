<script language="javascript">
    window.location = "http://localhost:8081/pms/public";
</script>
