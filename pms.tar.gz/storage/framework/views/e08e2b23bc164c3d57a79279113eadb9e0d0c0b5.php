<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Add Unit</div>

                <div class="panel-body">
                    <?php echo Form::open(['action' => 'UnitsController@add']); ?>

                      <div class="form-group">
                        <?php echo e(Form::label('unit', 'Unit')); ?>

                        <?php echo e(Form::text('unit', '', ['class' => 'form-control', 'placeholder' => 'Enter Unit'])); ?>

                        <?php echo e(Form::label('katashiki', 'Katashiki')); ?>

                        <?php echo e(Form::text('katashiki', '', ['class' => 'form-control', 'placeholder' => 'Enter Katashiki'])); ?>

                        <?php echo e(Form::label('suffix', 'Suffix')); ?>

                        <?php echo e(Form::text('suffix', '', ['class' => 'form-control', 'placeholder' => 'Enter Suffix'])); ?>

                      </div>
                      <div class="">
                        <?php echo e(Form::submit('submit', ['class' => 'btn btn-primary'])); ?>

                        <a class="btn btn-primary" href="<?php echo e(route('unit')); ?>">Cancel</a>
                      </div>

                    <?php echo Form:: close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>