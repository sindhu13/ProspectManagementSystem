<?php $__env->startSection('title', '| Create New Stock'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>
  <h1><i class='fa fa-user-plus'></i> Add Stock</h1>
  <hr>
    <div class="panel-body">
      <?php echo Form::open(array('url' => 'stocks')); ?>

      <div class="form-group">
        <?php echo e(Form::label('po_number', 'PO Number')); ?>

        <?php echo e(Form::text('po_number', '', ['class' => 'form-control', 'placeholder' => 'Enter PO Number'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('po_date', 'PO Date')); ?>

        <?php echo e(Form::text('po_date', '', ['class' => 'form-control', 'placeholder' => 'Enter PO Date'])); ?>

      </div>
      <?php echo e(Form::submit('Add', ['class' => 'btn btn-primary'])); ?>

      <a class="btn btn-primary" href="<?php echo e(route('stocks.index')); ?>">Cancel</a>
      <?php echo Form:: close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>