


<?php $__env->startSection('content'); ?>
    <div class='col-lg-4 col-lg-offset-4'>
        <h1><center>401<br>
        ACCESS DENIED</center></h1>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>