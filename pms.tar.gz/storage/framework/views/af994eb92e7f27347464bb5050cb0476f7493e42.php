

<?php $__env->startSection('title', '| Create New Position'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>
  <h1><i class='fa fa-user-plus'></i> Add Position</h1>
  <hr>
    <div class="panel-body">
      <?php echo Form::open(array('url' => 'positions')); ?>

      <div class="form-group">
        <?php echo e(Form::label('position', 'Position')); ?>

        <?php echo e(Form::text('position', '', ['class' => 'form-control', 'placeholder' => 'Enter Position'])); ?>

      </div>
      <?php echo e(Form::submit('Add', ['class' => 'btn btn-primary'])); ?>

      <a class="btn btn-primary" href="<?php echo e(route('positions.index')); ?>">Cancel</a>
      <?php echo Form:: close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>