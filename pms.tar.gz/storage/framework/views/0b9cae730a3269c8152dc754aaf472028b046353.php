<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Add Leasing</div>

                <div class="panel-body">
                    <?php echo Form::open(['action' => 'LeasingsController@add']); ?>

                      <div class="form-group">
                        <?php echo e(Form::label('leasing', 'Leasing')); ?>

                        <?php echo e(Form::text('leasing', '', ['class' => 'form-control', 'placeholder' => 'Enter Leasing'])); ?>

                        <?php echo e(Form::label('address', 'Address')); ?>

                        <?php echo e(Form::textarea('address', '', ['class' => 'form-control', 'placeholder' => 'Enter Address'])); ?>

                        <?php echo e(Form::label('phone', 'Phone')); ?>

                        <?php echo e(Form::text('phone', '', ['class' => 'form-control', 'placeholder' => 'Enter Phone'])); ?>

                      </div>
                      <div class="">
                        <?php echo e(Form::submit('submit', ['class' => 'btn btn-primary'])); ?>

                        <a class="btn btn-primary" href="<?php echo e(route('leasing')); ?>">Cancel</a>
                      </div>

                    <?php echo Form:: close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>