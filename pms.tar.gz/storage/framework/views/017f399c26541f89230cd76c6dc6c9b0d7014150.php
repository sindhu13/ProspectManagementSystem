

<?php $__env->startSection('title', '| Create New Location'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>
  <h1><i class='fa fa-user-plus'></i> Add Location</h1>
  <hr>
    <div class="panel-body">
      <?php echo Form::open(array('url' => 'locations')); ?>

      <div class="form-group">
        <?php echo e(Form::label('location', 'Location')); ?>

        <?php echo e(Form::text('location', '', ['class' => 'form-control', 'placeholder' => 'Enter Location'])); ?>

      </div>
      <?php echo e(Form::submit('Add', ['class' => 'btn btn-primary'])); ?>

      <a class="btn btn-primary" href="<?php echo e(route('locations.index')); ?>">Cancel</a>
      <?php echo Form:: close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>