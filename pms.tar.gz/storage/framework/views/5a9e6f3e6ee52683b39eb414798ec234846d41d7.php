<?php $__env->startSection('title', '| HOME'); ?>

<?php $__env->startSection('content'); ?>


<div class="col-lg-3 col-lg-offset-1">
  <h2>Barter</h2>
  <div style="font-size:50px; color:#0074D9;"><?php echo e($ts[0]); ?></div>
</div>

<div class="col-lg-10 col-lg-offset-1">
  <div>
    <iframe src ="<?php echo e(url('/barterIframe')); ?>" frameborder = "0" width = "100%" height = "610px" scrolling = "yes">This is iFrame</iframe>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>