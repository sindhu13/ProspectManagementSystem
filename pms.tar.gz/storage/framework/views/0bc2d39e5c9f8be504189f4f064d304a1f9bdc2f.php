<?php $__env->startSection('title', '| HOME'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-lg-10 col-lg-offset-1">
  <h1><i class="fa fa-users"></i>Stock Online</h1>
  <hr>
  <div class="table-responsive">
      <table class="table table-bordered table-striped">

          <thead>
              <tr>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 50px">No</th>
                <th colspan="3" style="text-align:center; vertical-align:middle;">Purchase Invoice</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 200px">Lokasi Fisik</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 230px">Vendor</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 300px">Type</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 170px">Chasis</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 110px">Engine</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 250px">Color</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 70px">Year</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 150px">Posisi Unit</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 150px">Alokasi Unit</th>
                <th colspan="2" style="text-align:center; vertical-align:middle;">Tangal Alokasi</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 220px">Nama Sales</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 220px">Nama Konsumen</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 100px">Leasing</th>
                <th style="text-align:center; vertical-align:middle; min-width: 150px">Posisi Terakhir</th>
                <th style="text-align:center; vertical-align:middle; min-width: 150px">Posisi Akhir HO</th>
                <th style="text-align:center; vertical-align:middle; min-width: 150px">Posisi Akhir HO</th>
              </tr>
              <tr>
                <th style="text-align:center; vertical-align:middle; min-width: 200px">No</th>
                <th style="text-align:center; vertical-align:middle;">Date</th>
                <th style="text-align:center; vertical-align:middle;">CSI</th>
                <th style="text-align:center; vertical-align:middle;">Hari</th>
                <th style="text-align:center; vertical-align:middle;">Tanggal</th>
                <th style="text-align:center; vertical-align:middle;">5 Hari Kerja</th>
                <th style="text-align:center; vertical-align:middle;">Tanggal Alokasi < 25</th>
                <th style="text-align:center; vertical-align:middle;">Tanggal Alokasi >= 25</th>
              </tr>
          </thead>

          <tbody>
            <tr>
              <td>1</td>
              <td>15MM.PI.1707.000680</td>
              <td>7/7/2017</td>
              <td>2017122038</td>
              <td>MERDEKA KIARACONDONG</td>
              <td>SETIAJAYA MOBILINDO DEPOK</td>
              <td>NEW RUSH 1.5 S A/T TRD SPORTIVO 40</td>
              <td>MHFE2CK3JHK045375</td>
              <td>3SZDGH7417</td>
              <td>DARK RED MICA METALLIC - 3Q3</td>
              <td>2017</td>
              <td>DISPLAY LEMBANG</td>
              <td>DISPLAY LEMBANG</td>
              <td>MINGGU</td>
              <td>8/30/2017</td>
              <td>MEIDIANSYAH PUTRA AGUNG</td>
              <td>RACHEL SUHARTATI BUDIONO</td>
              <td>BPR KS</td>
              <td>UNIT CABANG</td>
              <td>8/30/2017</td>
              <td>8/30/2017</td>
            </tr>
          </tbody>
      </table>
      <div class="text-center">

      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>