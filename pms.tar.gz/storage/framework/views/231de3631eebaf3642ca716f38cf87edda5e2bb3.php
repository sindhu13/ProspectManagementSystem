

<?php $__env->startSection('title', '| Edit Unit Model'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>

    <h1><i class='fa fa-user-plus'></i> Edit <?php echo e($unitModel->name); ?></h1>
    <hr>

    <?php echo e(Form::model($unitModel, array('route' => array('unitModels.update', $unitModel->id), 'method' => 'PUT'))); ?>

    <div class="form-group">
      <?php echo e(Form::label('name', 'Unit Model')); ?>

      <?php echo e(Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Enter Unit Model'])); ?>

    </div>
    <?php echo e(Form::submit('Save', array('class' => 'btn btn-primary'))); ?>

    <?php echo e(Form::close()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>