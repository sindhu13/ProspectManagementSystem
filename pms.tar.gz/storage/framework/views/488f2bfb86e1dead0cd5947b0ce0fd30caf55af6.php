

<?php $__env->startSection('title', '| Create New Unit Model'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>
  <h1><i class='fa fa-user-plus'></i> Add Unit Model</h1>
  <hr>
    <div class="panel-body">
      <?php echo Form::open(array('url' => 'unitModels')); ?>

      <div class="form-group">
        <?php echo e(Form::label('name', 'Unit Model')); ?>

        <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Enter Unit Model'])); ?>

      </div>
      <?php echo e(Form::submit('Add', ['class' => 'btn btn-primary'])); ?>

      <a class="btn btn-primary" href="<?php echo e(route('unitModels.index')); ?>">Cancel</a>
      <?php echo Form:: close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>