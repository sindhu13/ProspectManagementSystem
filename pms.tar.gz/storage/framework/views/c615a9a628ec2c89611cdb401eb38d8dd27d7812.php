<?php $__env->startSection('title', '| Edit Leasing'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>

    <h1><i class='fa fa-user-plus'></i> Edit <?php echo e($leasing->name); ?></h1>
    <hr>

    <?php echo e(Form::model($leasing, array('route' => array('leasings.update', $leasing->id), 'method' => 'PUT'))); ?>

    <div class="form-group">
      <?php echo e(Form::label('leasing', 'Leasing')); ?>

      <?php echo e(Form::text('leasing', null, ['class' => 'form-control', 'placeholder' => 'Enter Leasing'])); ?>

    </div>
    <div class="form-group">
      <?php echo e(Form::label('address', 'Address')); ?>

      <?php echo e(Form::textarea('address', null, ['class' => 'form-control', 'placeholder' => 'Enter Address'])); ?>

    </div>
    <div class="form-group">
      <?php echo e(Form::label('phone', 'Phone')); ?>

      <?php echo e(Form::text('phone', null, ['class' => 'form-control', 'placeholder' => 'Enter Phone'])); ?>

    </div>
    <div class="form-group">
      <?php echo e(Form::submit('Save', array('class' => 'btn btn-primary'))); ?>

      <?php echo e(Form::close()); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>