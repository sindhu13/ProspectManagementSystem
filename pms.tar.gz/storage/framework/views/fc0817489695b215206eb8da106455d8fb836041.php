

<?php $__env->startSection('title', '| Edit MarketingGroup'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>

    <h1><i class='fa fa-user-plus'></i> Edit <?php echo e($marketingGroup->name); ?></h1>
    <hr>

    <?php echo e(Form::model($marketingGroup, array('route' => array('marketingGroups.update', $marketingGroup->id), 'method' => 'PUT'))); ?>

    <div class="form-group">
      <?php echo e(Form::label('name', 'Name')); ?>

      <?php echo e(Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Enter Name'])); ?>

    </div>
    <div class="form-group">
        <?php echo e(Form::label('spv_id', 'Supervisor')); ?>

        <?php echo e(Form::select('spv_id', $employees, null, ['class' => 'form-control', 'placeholder' => 'Enter Supervisor'])); ?>

      </div>
    <?php echo e(Form::submit('Save', array('class' => 'btn btn-primary'))); ?>

    <?php echo e(Form::close()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>