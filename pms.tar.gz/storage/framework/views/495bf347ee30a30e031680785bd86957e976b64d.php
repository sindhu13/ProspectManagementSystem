

<?php $__env->startSection('title', '| Edit Unit'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>

    <h1><i class='fa fa-user-plus'></i> Edit <?php echo e($unit->name); ?></h1>
    <hr>

    <?php echo e(Form::model($unit, array('route' => array('units.update', $unit->id), 'method' => 'PUT'))); ?>

    <div class="form-group">
        <?php echo e(Form::label('unit_model_id', 'Unit Model')); ?>

        <?php echo e(Form::select('unit_model_id', $models, null, ['class' => 'form-control', 'placeholder' => 'Enter Unit Model'])); ?>

      </div>
    <div class="form-group">
      <?php echo e(Form::label('unit', 'Unit')); ?>

      <?php echo e(Form::text('unit', null, ['class' => 'form-control', 'placeholder' => 'Enter Unit'])); ?>

    </div>
    <div class="form-group">
      <?php echo e(Form::label('katashiki', 'Katashiki')); ?>

      <?php echo e(Form::text('katashiki', null, ['class' => 'form-control', 'placeholder' => 'Enter Katashiki'])); ?>

    </div>
    <div class="form-group">
      <?php echo e(Form::label('suffix', 'Suffix')); ?>

      <?php echo e(Form::text('suffix', null, ['class' => 'form-control', 'placeholder' => 'Enter Suffix'])); ?>

    </div>
    <?php echo e(Form::submit('Save', array('class' => 'btn btn-primary'))); ?>

    <?php echo e(Form::close()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>