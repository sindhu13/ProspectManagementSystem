<?php $__env->startSection('title', '| HOME'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-lg-2 col-lg-offset-1">
  <h2>Stock</h2>
  <div style="font-size:50px; color:#0074D9;"><?php echo e($tst[0]); ?></div>  
</div>
  
<div class="col-lg-2 col-lg-offset-1">
  <h2>Supplies</h2>
  <div style="font-size:50px; color:#0074D9;"><a href="<?php echo e(url('/supply/')); ?>"><?php echo e($tsp[0]); ?></a></div>
</div>

<div class="col-lg-2 col-lg-offset-1">
  <h2>Sales</h2>
  <div style="font-size:50px; color:#0074D9;"><a href="<?php echo e(url('/do/')); ?>"><?php echo e($tsdo[0]); ?></a></div>
</div>

<div class="col-lg-2 col-lg-offset-1">
  <h2>Barter</h2>
  <div style="font-size:50px; color:#0074D9;"><a href="<?php echo e(url('/barter/')); ?>"><?php echo e($tsdou[0]); ?></a></div>
</div>
  
<div class="col-lg-10 col-lg-offset-1">
  <div>
    <iframe src ="<?php echo e(url('/homeIframe')); ?>" frameborder = "0" width = "100%" height = "610px" scrolling = "yes">This is iFrame</iframe>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>