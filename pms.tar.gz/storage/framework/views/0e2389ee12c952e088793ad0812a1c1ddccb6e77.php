<?php $__env->startSection('title', '| Users'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-lg-10 col-lg-offset-1">
  <h1><i class="fa fa-users"></i> Leasings <a href="<?php echo e(route('leasings.create')); ?>" class="btn btn-default pull-right">Add Leasings</a></h1>
  <hr>
  <div class="table-responsive">
      <table class="table table-bordered table-striped">

          <thead>
              <tr>
                <th>No</th>
                <th>Leasing</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Last Modified</th>
                <th>Operations</th>
              </tr>
          </thead>

          <tbody>
              <?php ($i = 0); ?>
              <?php $__currentLoopData = $leasings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leasing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php ($i++); ?>
              <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($leasing->leasing); ?></td>
                <td><?php echo e($leasing->address); ?></td>
                <td><?php echo e($leasing->phone); ?></td>
                <td><?php echo e(date('d m Y', strtotime($leasing->created_at))); ?></td>
                <td>
                <a href="<?php echo e(route('leasings.edit', $leasing->id)); ?>" class="btn btn-info pull-left" style="margin-right: 3px;">Edit</a>

                <?php echo Form::open(['method' => 'DELETE', 'route' => ['leasings.destroy', $leasing->id], 'class' => 'delete' ]); ?>

                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                <?php echo Form::close(); ?>


                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
      <div class="text-center">
          <?php echo $leasings->links(); ?>

      </div>
  </div>
</div>

<script>
  $(".delete").on("submit", function(){
    return confirm("Do you want to delete this item ?");
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>