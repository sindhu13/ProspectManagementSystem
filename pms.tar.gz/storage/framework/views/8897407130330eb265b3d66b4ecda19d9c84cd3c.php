<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Add Color</div>

                <div class="panel-body">
                    <?php echo Form::open(['action' => 'ColorsController@add']); ?>

                      <div class="form-group">
                        <?php echo e(Form::label('color', 'Color')); ?>

                        <?php echo e(Form::text('color', '', ['class' => 'form-control', 'placeholder' => 'Enter Color'])); ?>

                        <?php echo e(Form::label('code', 'Code')); ?>

                        <?php echo e(Form::text('code', '', ['class' => 'form-control', 'placeholder' => 'Enter Code'])); ?>

                      </div>
                      <div class="">
                        <?php echo e(Form::submit('submit', ['class' => 'btn btn-primary'])); ?>

                        <a class="btn btn-primary" href="<?php echo e(route('color')); ?>">Cancel</a>
                      </div>

                    <?php echo Form:: close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>