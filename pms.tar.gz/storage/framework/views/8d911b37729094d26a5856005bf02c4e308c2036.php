<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Units</div>

                <div class="panel-body">
                  <div class="container col-md-12">
                    <table class="table table-striped table-hover table-sm">
                      <thead class="thead-inverse">
                        <tr>
                          <th>No</th>
                          <th>Unit</th>
                          <th>Last Modified</th>
                        </tr>
                      </thead>
                      <tbody class="">
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++; ?>
                            <tr>
                              <td><?php echo e($i); ?></td>
                              <td><?php echo e($unit->unit." ".$unit->suffix); ?></td>
                              <td><?php echo e(date('d m Y', strtotime($unit->created_at))); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                    <?php echo e($units->links()); ?>

                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>