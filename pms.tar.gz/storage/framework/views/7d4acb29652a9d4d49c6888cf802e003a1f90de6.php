<?php $__env->startSection('title', '| View Seller'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

    <h1><?php echo e($seller->name); ?></h1>
    <hr>
    <p class="lead"><?php echo e($seller->phone); ?> </p>
    <p class="lead"><?php echo e($seller->address); ?> </p>
    <p class="lead"><?php echo e($seller->position); ?> </p>
    <hr>
    <?php echo Form::open(['method' => 'DELETE', 'route' => ['sellers.destroy', $seller->id] ]); ?>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary">Back</a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Seller')): ?>
    <a href="<?php echo e(route('sellers.edit', $seller->id)); ?>" class="btn btn-info" role="button">Edit</a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Delete Seller')): ?>
    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

    <?php endif; ?>
    <?php echo Form::close(); ?>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>