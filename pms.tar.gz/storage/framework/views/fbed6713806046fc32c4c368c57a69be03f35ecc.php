<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Leasings</div>

                <div class="panel-body">
                  <div class="container col-md-12">
                    <table class="table table-striped table-hover table-sm">
                      <thead class="thead-inverse">
                        <tr>
                          <th>No</th>
                          <th>Leasing</th>
                          <th>Address</th>
                          <th>Phone</th>
                          <th>Last Modified</th>
                        </tr>
                      </thead>
                      <tbody class="">
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $leasings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leasing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++; ?>
                            <tr>
                              <td><?php echo e($i); ?></td>
                              <td><?php echo e($leasing->leasing); ?></td>
                              <td><?php echo e($leasing->address); ?></td>
                              <td><?php echo e($leasing->phone); ?></td>
                              <td><?php echo e(date('d m Y', strtotime($leasing->created_at))); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                    <?php echo e($leasings->links()); ?>

                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>