

<?php $__env->startSection('title', '| Edit User Has Seller'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>

    <h1><i class='fa fa-user-plus'></i> Edit <?php echo e($userHasSeller->name); ?></h1>
    <hr>

    <?php echo e(Form::model($userHasSeller, array('route' => array('userHasSellers.update', $userHasSeller->id), 'method' => 'PUT'))); ?>

    <?php echo e(Form::hidden('marketing_id', null)); ?>

    <?php echo e(Form::hidden('employee_id', null)); ?>

        <div class="form-group">
            <?php echo e(Form::label('employee_id', 'Seller')); ?>

            <?php echo e(Form::select('employee_id', $employees, null, ['class' => 'form-control', 'placeholder' => 'Enter Seller', 'disabled' => 'disabled'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('begin_work', 'Begin Work')); ?>

            <?php echo e(Form::text('begin_work', null, ['class' => 'form-control', 'placeholder' => 'Enter Begin Work'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('end_work', 'End Work')); ?>

            <?php echo e(Form::text('end_work', null, ['class' => 'form-control', 'placeholder' => 'Enter End Work'])); ?>

        </div>
    <?php echo e(Form::submit('Save', array('class' => 'btn btn-primary'))); ?>

    <?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>