


<?php $__env->startSection('title', '| Positions'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-lg-10 col-lg-offset-1">
  <h1><i class="fa fa-users"></i> Positions <a href="<?php echo e(route('positions.create')); ?>" class="btn btn-default pull-right">Add Positions</a></h1>
  <hr>
  <div class="table-responsive">
      <table class="table table-bordered table-striped">

          <thead>
              <tr>
                <th>No</th>
                <th>Position</th>
                <th>Last Modified</th>
                <th>Operations</th>
              </tr>
          </thead>

          <tbody>
              <?php ($i = 0); ?>
              <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php ($i++); ?>
              <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($position->position); ?></td>
                <td><?php echo e(date('d m Y', strtotime($position->created_at))); ?></td>
                <td>
                <a href="<?php echo e(route('positions.edit', $position->id)); ?>" class="btn btn-info pull-left" style="margin-right: 3px;">Edit</a>

                <?php echo Form::open(['method' => 'DELETE', 'route' => ['positions.destroy', $position->id], 'class' => 'delete' ]); ?>

                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                <?php echo Form::close(); ?>


                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
      <div class="text-center">
          <?php echo $positions->links(); ?>

      </div>
  </div>
</div>

<script>
  $(".delete").on("submit", function(){
    return confirm("Do you want to delete this item ?");
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>