<div style="overflow:hidden;">
  <div class="" style="max-width: 500px; float:left;">
    <h2>Ranking</h2>
    <div class="table-responsive">
      <table class="table table-bordered table-striped" style="background-color: #f2f2f2;">
        <thead>
          <tr style="background-color: #e6e6e6;">
            <th>Ranking</th>
            <th>Team</th>
            <th>Total</th>
          </tr>
        </thead>

        <tbody>
          <?php ($i = 0); ?>
          <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php ($i++); ?>
            <tr>
              <td><?php echo e($i); ?></td>
              <td style="font-weight: bold;"><?php echo e($sale->name); ?></td>
              <td><?php echo e($sale->tot); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php $__currentLoopData = $marketings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php ($name = 'f'); ?>
          <?php ($t = $marketing->name); ?>
            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($name == 'f'): ?>
                <?php if($sale->id == $marketing->id): ?>
                  <?php ($name = 't'); ?>
                <?php endif; ?>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($name == 'f'): ?>
            <tr>
              <?php ($i++); ?>
              <td><?php echo e($i); ?></td>
              <td style="font-weight: bold;"><?php echo e($t); ?></td>
              <td>0</td>
            </tr>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>


  <div class="" style="max-width: 500px; float:right;">
    <h2>Daily Activity</h2>
    <div class="table-responsive">
      <table class="table table-bordered table-striped" style="background-color: #f2f2f2;">
        <thead>
          <tr style="background-color: #e6e6e6;">
            <th>Sales</th>
            <th>Today</th>
          </tr>
        </thead>

        <tbody>
          <?php $__currentLoopData = $salesperday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td style="font-weight: bold;"><?php echo e($sale->name); ?></td>
              <td><?php echo e($sale->tot); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php ($name = 'f'); ?>
          <?php ($t = $seller->name); ?>
            <?php $__currentLoopData = $salesperday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($name == 'f'): ?>
                <?php if($sale->id == $seller->id): ?>
                  <?php ($name = 't'); ?>
                <?php endif; ?>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($name == 'f'): ?>
            <tr>
              <td style="font-weight: bold;" class="zero"><?php echo e($t); ?></td>
              <td>0</td>
            </tr>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
    </div>
  </div>
</div>
