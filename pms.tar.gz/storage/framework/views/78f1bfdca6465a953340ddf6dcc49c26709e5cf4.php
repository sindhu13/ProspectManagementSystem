<?php $__env->startSection('title', '| Sales Per Color'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-lg-10 col-lg-offset-1">
  <h1><i class="fa fa-users"></i> Sales Per Color </h1>
  <hr>
  <?php echo Form::open(['method' => 'get', 'url' => '/salespercolor', 'class' => 'navbar-form navbar-right', 'role' => 'search']); ?>

  <?php ($now = Carbon\Carbon::now()); ?>
  <?php echo e(Form::selectYear('yearsearch', $now->year, 2015, $now->year, ['class' => 'form-control'])); ?>

  <?php echo e(Form::submit('Search', array('class' => 'btn btn-primary'))); ?>

  <?php echo Form:: close(); ?></br></br></br>
  <div class="table-responsive">
    <?php
    $n = \Carbon\Carbon::now();
    ?>
    <div class="table-responsive">
      <table class="table table-bordered table-striped" style="background-color: #f2f2f2;">
        <thead>
          <tr style="background-color: #e6e6e6;">
            <th>Color</th>
            <th>January</th>
            <th>February</th>
            <th>March</th>
            <th>April</th>
            <th>May</th>
            <th>June</th>
            <th>July</th>
            <th>August</th>
            <th>September</th>
            <th>October</th>
            <th>November</th>
            <th>December</th>
            <th>Total</th>
          </tr>
        </thead>

        <tbody>
          <?php ($gvars = array(
            'jan' => array('month' => 1, 'tot' => 0), 'feb' => array('month' => 2, 'tot' => 0), 'mar' => array('month' => 3, 'tot' => 0),
            'apr' => array('month' => 4, 'tot' => 0), 'mei' => array('month' => 5, 'tot' => 0), 'jun' => array('month' => 6, 'tot' => 0),
            'jul' => array('month' => 7, 'tot' => 0), 'aug' => array('month' => 8, 'tot' => 0), 'sep' => array('month' => 9, 'tot' => 0),
            'oct' => array('month' => 10, 'tot' => 0), 'nov' => array('month' => 11, 'tot' => 0), 'dec' => array('month' => 12, 'tot' => 0),
          )); ?>
          <?php ($gsstot = 0); ?>
          <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($vars = array(
              'jan' => array('month' => 1, 'tot' => 0), 'feb' => array('month' => 2, 'tot' => 0), 'mar' => array('month' => 3, 'tot' => 0),
              'apr' => array('month' => 4, 'tot' => 0), 'mei' => array('month' => 5, 'tot' => 0), 'jun' => array('month' => 6, 'tot' => 0),
              'jul' => array('month' => 7, 'tot' => 0), 'aug' => array('month' => 8, 'tot' => 0), 'sep' => array('month' => 9, 'tot' => 0),
              'oct' => array('month' => 10, 'tot' => 0), 'nov' => array('month' => 11, 'tot' => 0), 'dec' => array('month' => 12, 'tot' => 0),
            )); ?>
            <?php ($sstot = 0); ?>
            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($sale->id == $color->id): ?>
                <?php if($sale->m == 1): ?>
                  <?php ($vars['jan']['tot'] = $sale->tot); ?>
                  <?php ($gvars['jan']['tot'] += $sale->tot); ?>
                <?php elseif($sale->m == 2): ?>
                  <?php ($vars['feb']['tot'] = $sale->tot); ?>
                  <?php ($gvars['feb']['tot'] += $sale->tot); ?>
                <?php elseif($sale->m == 3): ?>
                  <?php ($vars['mar']['tot'] = $sale->tot); ?>
                  <?php ($gvars['mar']['tot'] += $sale->tot); ?>
                <?php elseif($sale->m == 4): ?>
                  <?php ($vars['apr']['tot'] = $sale->tot); ?>
                  <?php ($gvars['apr']['tot'] += $sale->tot); ?>
                <?php elseif($sale->m == 5): ?>
                  <?php ($vars['mei']['tot'] = $sale->tot); ?>
                  <?php ($gvars['mei']['tot'] += $sale->tot); ?>
                <?php elseif($sale->m == 6): ?>
                  <?php ($vars['jun']['tot'] = $sale->tot); ?>
                  <?php ($gvars['jun']['tot'] += $sale->tot); ?>
                <?php elseif($sale->m == 7): ?>
                  <?php ($vars['jul']['tot'] = $sale->tot); ?>
                  <?php ($gvars['jul']['tot'] += $sale->tot); ?>
                <?php elseif($sale->m == 8): ?>
                  <?php ($vars['aug']['tot'] = $sale->tot); ?>
                  <?php ($gvars['aug']['tot'] += $sale->tot); ?>
                <?php elseif($sale->m == 9): ?>
                  <?php ($vars['sep']['tot'] = $sale->tot); ?>
                  <?php ($gvars['sep']['tot'] += $sale->tot); ?>
                <?php elseif($sale->m == 10): ?>
                  <?php ($vars['oct']['tot'] = $sale->tot); ?>
                  <?php ($gvars['oct']['tot'] += $sale->tot); ?>
                <?php elseif($sale->m == 11): ?>
                  <?php ($vars['nov']['tot'] = $sale->tot); ?>
                  <?php ($gvars['nov']['tot'] += $sale->tot); ?>
                <?php elseif($sale->m == 11): ?>
                  <?php ($vars['dec']['tot'] = $sale->tot); ?>
                  <?php ($gvars['dec']['tot'] += $sale->tot); ?>
                <?php endif; ?>
                <?php ($sstot += $sale->tot); ?>
                <?php ($year = $sale->y); ?>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php ($gsstot += $sstot); ?>
            <tr>
              <td style="font-weight: bold;"><?php echo e($color->color .' - '. $color->code); ?></td>
              <td><?php echo e($vars['jan']['tot']); ?></td><td><?php echo e($vars['feb']['tot']); ?></td><td><?php echo e($vars['mar']['tot']); ?></td><td><?php echo e($vars['apr']['tot']); ?></td>
              <td><?php echo e($vars['mei']['tot']); ?></td><td><?php echo e($vars['jun']['tot']); ?></td><td><?php echo e($vars['jul']['tot']); ?></td><td><?php echo e($vars['aug']['tot']); ?></td>
              <td><?php echo e($vars['sep']['tot']); ?></td><td><?php echo e($vars['oct']['tot']); ?></td><td><?php echo e($vars['nov']['tot']); ?></td><td><?php echo e($vars['dec']['tot']); ?></td>
              <td style="font-weight: bold;"><?php echo e($sstot); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          <tr style="font-weight: bold;">
            <td>GRAND TOTAL</td>
            <td><?php echo e($gvars['jan']['tot']); ?></td><td><?php echo e($gvars['feb']['tot']); ?></td><td><?php echo e($gvars['mar']['tot']); ?></td><td><?php echo e($gvars['apr']['tot']); ?></td>
            <td><?php echo e($gvars['mei']['tot']); ?></td><td><?php echo e($gvars['jun']['tot']); ?></td><td><?php echo e($gvars['jul']['tot']); ?></td><td><?php echo e($gvars['aug']['tot']); ?></td>
            <td><?php echo e($gvars['sep']['tot']); ?></td><td><?php echo e($gvars['oct']['tot']); ?></td><td><?php echo e($gvars['nov']['tot']); ?></td><td><?php echo e($gvars['dec']['tot']); ?></td>
            <td><?php echo e($gsstot); ?></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>