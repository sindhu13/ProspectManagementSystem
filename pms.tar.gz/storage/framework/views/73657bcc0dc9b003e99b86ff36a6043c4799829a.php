

<?php $__env->startSection('title', '| Edit Stock'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>

    <h1><i class='fa fa-user-plus'></i> Edit <?php echo e($stock->name); ?></h1>
    <hr>

    <?php echo e(Form::model($stock, array('route' => array('stocks.update', $stock->id), 'method' => 'PUT'))); ?>

    <div class="form-group">
        <?php echo e(Form::label('po_number', 'PO Number')); ?>

        <?php echo e(Form::text('po_number', null, ['class' => 'form-control', 'placeholder' => 'Enter PO Number'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('po_date', 'PO Date')); ?>

        <?php echo e(Form::text('po_date', null, ['class' => 'form-control', 'placeholder' => 'Enter PO Date'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('po_csi', 'PO CSI')); ?>

        <?php echo e(Form::text('po_csi', null, ['class' => 'form-control', 'placeholder' => 'Enter PO CSI Number'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('location_id', 'Physical Location')); ?>

        <?php echo e(Form::select('location_id', $locations, null, ['class' => 'form-control', 'placeholder' => 'Enter Physical Location'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('vendor_id', 'Vendor name')); ?>

        <?php echo e(Form::select('vendor_id', $vendors, null, ['class' => 'form-control', 'placeholder' => 'Enter Vendor Name'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('unit_id', 'Unit Type')); ?>        
        <select name="unit_id" class="form-control">
        <option selected="selected" disabled="disabled" hidden="hidden" value="">Enter Unit Type</option>
        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($isselectedu = ''); ?>
            <?php if($unit['id'] == $stock->unit_id): ?>
                <?php ($isselectedu = 'selected'); ?>
            <?php endif; ?>
                <option value="<?php echo e($unit['id']); ?>" <?php echo e($isselectedu); ?>><?php echo e($unit['unit'].' - '.$unit['suffix']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <?php echo e(Form::label('chassis', 'Chassis')); ?>

        <?php echo e(Form::text('chassis', null, ['class' => 'form-control', 'placeholder' => 'Enter Chassis'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('engine', 'Engine')); ?>

        <?php echo e(Form::text('engine', null, ['class' => 'form-control', 'placeholder' => 'Enter Engine'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('color_id', 'Color')); ?>

        <select name="color_id" class="form-control">
        <option selected="selected" disabled="disabled" hidden="hidden" value="">Enter Color</option>
        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($isselectedc = ''); ?>
            <?php if($color['id'] == $stock->color_id): ?>
                <?php ($isselectedc = 'selected'); ?>
            <?php endif; ?>
          <option value="<?php echo e($color['id']); ?>" <?php echo e($isselectedc); ?>><?php echo e($color['color'].' - '.$color['code']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <?php echo e(Form::label('year', 'Year')); ?>

        <?php echo e(Form::selectyear('year', date("Y", strtotime(\Carbon\Carbon::now())), 2013, null, ['class' => 'form-control'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('position_id', 'Position')); ?>

        <?php echo e(Form::select('position_id', $positions, null, ['class' => 'form-control', 'placeholder' => 'Enter Position'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('alocation_id', 'Alocation')); ?>

        <?php echo e(Form::select('alocation_id', $alocations, null, ['class' => 'form-control', 'placeholder' => 'Enter Alocation'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('alocation_day', 'Alocation Day')); ?>

        <?php ($days = array("Sunday" => "Sunday", "Monday" => "Monday", "Tuesday" => "Tuesday", "Wednesday" => "Wednesday", "Thursday" => "Thursday", "Friday" => "Friday", "Saturday" => "Saturday")); ?>
        <?php echo e(Form::select('alocation_day', $days, null, ['class' => 'form-control', 'placeholder' => 'Enter Alocation Day'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('alocation_date', 'Alocation Date')); ?>

        <?php echo e(Form::text('alocation_date', null, ['class' => 'form-control', 'placeholder' => 'Enter Alocation Date'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('seller_id', 'Seller')); ?>

        <select name="seller_id" class="form-control">
        <option selected="selected" disabled="disabled" hidden="hidden" value="">Enter Seller</option>
        <?php $__currentLoopData = $marketings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <optgroup label="<?php echo e($marketing->name); ?>">
            <?php $__currentLoopData = $userHasSellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userHasSeller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($marketing->id == $userHasSeller->marketing_id): ?>
                <?php ($selectseller = ''); ?>
                <?php if($userHasSeller->id == $stock->seller_id): ?>
                    <?php ($selectseller = 'selected'); ?>
                <?php endif; ?>
              <option value="<?php echo e($userHasSeller->id); ?>" <?php echo e($selectseller); ?>><?php echo e($userHasSeller->seller); ?></option>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </optgroup>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <?php echo e(Form::label('consumer', 'Customer')); ?>

        <?php echo e(Form::text('consumer', null, ['class' => 'form-control', 'placeholder' => 'Enter Customer'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('leasing_id', 'Leasing')); ?>

        <?php echo e(Form::select('leasing_id', $leasings, null, ['class' => 'form-control', 'placeholder' => 'Enter Leasing'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('last_status_id', 'Status')); ?>

        <?php echo e(Form::select('last_status_id', $status, '', ['class' => 'form-control', 'placeholder' => 'Enter Status'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('status_date', 'Status Date')); ?>

        <?php echo e(Form::text('status_date', '', ['class' => 'form-control', 'placeholder' => 'Enter Status Date'])); ?>

      </div>
    <?php echo e(Form::submit('Save', array('class' => 'btn btn-primary'))); ?>

    <?php echo e(Form::close()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>