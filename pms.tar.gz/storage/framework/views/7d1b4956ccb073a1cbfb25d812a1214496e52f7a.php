

<?php $__env->startSection('title', '| Create New Unit'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>
  <h1><i class='fa fa-user-plus'></i> Add Unit</h1>
  <hr>
    <div class="panel-body">
      <?php echo Form::open(array('url' => 'units')); ?>

      <div class="form-group">
        <?php echo e(Form::label('unit_model_id', 'Unit Model')); ?>

        <?php echo e(Form::select('unit_model_id', $models, '', ['class' => 'form-control', 'placeholder' => 'Enter Unit Model'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('unit', 'Unit')); ?>

        <?php echo e(Form::text('unit', '', ['class' => 'form-control', 'placeholder' => 'Enter Unit'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('katashiki', 'Katashiki')); ?>

        <?php echo e(Form::text('katashiki', '', ['class' => 'form-control', 'placeholder' => 'Enter Katashiki'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('suffix', 'Suffix')); ?>

        <?php echo e(Form::text('suffix', '', ['class' => 'form-control', 'placeholder' => 'Enter Suffix'])); ?>

      </div>
      <?php echo e(Form::submit('Add', ['class' => 'btn btn-primary'])); ?>

      <a class="btn btn-primary" href="<?php echo e(route('units.index')); ?>">Cancel</a>
      <?php echo Form:: close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>