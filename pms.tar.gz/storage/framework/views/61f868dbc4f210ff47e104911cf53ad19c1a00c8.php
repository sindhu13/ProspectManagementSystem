<?php $__env->startSection('title', '| Colors'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-lg-10 col-lg-offset-1">
  <h1><i class="fa fa-users"></i> Colors <a href="<?php echo e(route('colors.create')); ?>" class="btn btn-default pull-right">Add Colors</a></h1>
  <hr>
  <div class="table-responsive">
      <table class="table table-bordered table-striped">

          <thead>
              <tr>
                <th>No</th>
                <th>Color</th>
                <th>Code</th>
                <th>Last Modified</th>
                <th>Operations</th>
              </tr>
          </thead>

          <tbody>
              <?php ($i = 0); ?>
              <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php ($i++); ?>
              <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($color->color); ?></td>
                <td><?php echo e($color->code); ?></td>
                <td><?php echo e(date('d m Y', strtotime($color->created_at))); ?></td>
                <td>
                <a href="<?php echo e(route('colors.edit', $color->id)); ?>" class="btn btn-info pull-left" style="margin-right: 3px;">Edit</a>

                <?php echo Form::open(['method' => 'DELETE', 'route' => ['colors.destroy', $color->id], 'class' => 'delete' ]); ?>

                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                <?php echo Form::close(); ?>


                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
      <div class="text-center">
          <?php echo $colors->links(); ?>

      </div>
  </div>
</div>

<script>
  $(".delete").on("submit", function(){
    return confirm("Do you want to delete this item ?");
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>