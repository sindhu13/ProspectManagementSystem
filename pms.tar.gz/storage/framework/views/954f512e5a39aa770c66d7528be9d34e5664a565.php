<?php $__env->startSection('title', '| HOME'); ?>

<?php $__env->startSection('content'); ?>


<div class="">
  <div class="">
      <table class="table table-bordered table-striped">

          <thead>
              <tr>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 50px">No</th>
                <th colspan="3" style="text-align:center; vertical-align:middle;">Purchase Invoice</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 200px">Lokasi Fisik</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 230px">Vendor</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 300px">Type</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 170px">Chasis</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 110px">Engine</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 250px">Color</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 70px">Year</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 150px">Posisi Unit</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 150px">Alokasi Unit</th>
                <th colspan="2" style="text-align:center; vertical-align:middle; min-width: 110px">Tangal Alokasi</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 220px">Nama Sales</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 220px">Nama Konsumen</th>
                <th rowspan="2" style="text-align:center; vertical-align:middle; min-width: 100px">Leasing</th>
                <th style="text-align:center; vertical-align:middle; min-width: 150px">Posisi Terakhir</th>
                <th style="text-align:center; vertical-align:middle; min-width: 150px">Posisi Akhir HO</th>
                <th style="text-align:center; vertical-align:middle; min-width: 150px">Posisi Akhir HO</th>
                <th style="text-align:center; vertical-align:middle; min-width: 150px">Status</th>
              </tr>
              <tr>
                <th style="text-align:center; vertical-align:middle; min-width: 200px">No</th>
                <th style="text-align:center; vertical-align:middle; min-width: 100px">Date</th>
                <th style="text-align:center; vertical-align:middle;">CSI</th>
                <th style="text-align:center; vertical-align:middle;">Hari</th>
                <th style="text-align:center; vertical-align:middle; min-width: 100px">Tanggal</th>
                <th style="text-align:center; vertical-align:middle;">5 Hari Kerja</th>
                <th style="text-align:center; vertical-align:middle;">Tanggal Alokasi < 25</th>
                <th style="text-align:center; vertical-align:middle;">Tanggal Alokasi >= 25</th>
              </tr>
          </thead>

          <tbody>
              <?php ($i = 0); ?>
              <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php ($i++); ?>
              <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($stock->po_number); ?></td>
                <td><?php echo e(date('d m Y', strtotime($stock->created_at))); ?></td>
                <td><?php echo e($stock->po_csi); ?></td>
                <td><?php echo e($stock->location); ?></td>
                <td><?php echo e($stock->vendor); ?></td>
                <td><?php echo e($stock->unit.' - '. $stock->suffix); ?></td>
                <td><?php echo e($stock->chassis); ?></td>
                <td><?php echo e($stock->engine); ?></td>
                <td><?php echo e($stock->color.' - '. $stock->code); ?></td>
                <td><?php echo e($stock->year); ?></td>
                <td><?php echo e($stock->position); ?></td>
                <td><?php echo e($stock->aloc); ?></td>
                <td><?php echo e($stock->alocation_day); ?></td>
                <td><?php echo e(!isset($stock->alocation_date) ? '' : date('d m Y', strtotime($stock->alocation_date))); ?></td>
                <td><?php echo e($stock->name); ?></td>
                <td><?php echo e($stock->consumer); ?></td>
                <td><?php echo e($stock->leasing); ?></td>
                <td><?php echo e($stock->last_pos); ?></td>
                <td><?php echo e(!isset($stock->last_pos_ho_less) ? '' : date('d m Y', strtotime($stock->last_pos_ho_less))); ?></td>
                <td><?php echo e(!isset($stock->last_pos_ho_greater) ? '' : date('d m Y', strtotime($stock->last_pos_ho_greater))); ?></td>
                <td><?php echo e($stock->status); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
      <div class="text-center">
          <?php echo $stocks->links(); ?>

      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appIframe', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>