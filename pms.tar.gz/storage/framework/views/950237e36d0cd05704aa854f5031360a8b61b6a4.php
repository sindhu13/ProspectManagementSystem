<?php $__env->startSection('title', '| Create New Seller'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>
  <h1><i class='fa fa-user-plus'></i> Add Seller</h1>
  <hr>
    <div class="panel-body">
      <?php echo Form::open(array('url' => 'sellers')); ?>

      <div class="form-group">
        <?php echo e(Form::label('name', 'Name')); ?>

        <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Enter Name'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('phone', 'Phone')); ?>

        <?php echo e(Form::text('phone', '', ['class' => 'form-control', 'placeholder' => 'Enter Phone'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('address', 'Address')); ?>

        <?php echo e(Form::textarea('address', '', ['class' => 'form-control', 'placeholder' => 'Enter Address'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('position', 'Position')); ?>

        <?php echo e(Form::text('position', '', ['class' => 'form-control', 'placeholder' => 'Enter Position'])); ?>

      </div>
      <?php echo e(Form::submit('Add', ['class' => 'btn btn-primary'])); ?>

      <a class="btn btn-primary" href="<?php echo e(route('sellers.index')); ?>">Cancel</a>
      <?php echo Form:: close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>