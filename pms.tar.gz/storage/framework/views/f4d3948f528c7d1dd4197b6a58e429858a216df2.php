<?php echo Form::open(['method' => 'get', 'url' => $url, 'class' => 'navbar-form navbar-right', 'role' => 'search']); ?>

<?php echo e(Form::text('search', '', ['class' => 'form-control', 'placeholder' => 'Search...'])); ?>

<?php ($now = Carbon\Carbon::now()); ?>
<?php echo e(Form::selectMonth('monthsearch', $now->month, ['class' => 'form-control'])); ?>

<?php echo e(Form::submit('Search', array('class' => 'btn btn-primary'))); ?>

<?php echo Form:: close(); ?>



<!--<div class="input-group custom-search-form">
    <input type="text" class="form-control" name="search" placeholder="Search...">
    <span class="input-group-btn">
        <button class="btn btn-default-sm" type="submit">
            <i class="fa fa-search"> </i>
        </button>
    </span>
</div>-->