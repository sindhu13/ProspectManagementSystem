<?php $__env->startSection('title', '| Create New Color'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>
  <h1><i class='fa fa-user-plus'></i> Add Color</h1>
  <hr>
    <div class="panel-body">
      <?php echo Form::open(array('url' => 'colors')); ?>

      <div class="form-group">
        <?php echo e(Form::label('color', 'Color')); ?>

        <?php echo e(Form::text('color', '', ['class' => 'form-control', 'placeholder' => 'Enter Color'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('code', 'Code')); ?>

        <?php echo e(Form::text('code', '', ['class' => 'form-control', 'placeholder' => 'Enter Code'])); ?>

      </div>
      <?php echo e(Form::submit('Add', ['class' => 'btn btn-primary'])); ?>

      <a class="btn btn-primary" href="<?php echo e(route('colors.index')); ?>">Cancel</a>
      <?php echo Form:: close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>