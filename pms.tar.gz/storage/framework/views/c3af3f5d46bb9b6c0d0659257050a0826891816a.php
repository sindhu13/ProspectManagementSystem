<?php $__env->startSection('title', '| Create New Vendor'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>
  <h1><i class='fa fa-user-plus'></i> Add Vendor</h1>
  <hr>
    <div class="panel-body">
      <?php echo Form::open(array('url' => 'vendors')); ?>

      <div class="form-group">
        <?php echo e(Form::label('vendor', 'Vendor')); ?>

        <?php echo e(Form::text('vendor', '', ['class' => 'form-control', 'placeholder' => 'Enter Vendor'])); ?>

      </div>
      <?php echo e(Form::submit('Add', ['class' => 'btn btn-primary'])); ?>

      <a class="btn btn-primary" href="<?php echo e(route('vendors.index')); ?>">Cancel</a>
      <?php echo Form:: close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>