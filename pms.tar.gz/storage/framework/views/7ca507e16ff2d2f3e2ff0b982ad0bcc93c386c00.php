

<?php $__env->startSection('title', '| View Marketing Group'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php $__currentLoopData = $marketingGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketingGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1>Group Marketing <?php echo e($marketingGroup->name); ?></h1>
    <h2>Supervisor : <?php echo e($marketingGroup->spv); ?></h2>
        <?php ($idm = $marketingGroup->id); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <?php echo Form::open(['method' => 'DELETE', 'route' => ['marketingGroups.destroy', 1] ]); ?>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary">Back</a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Seller')): ?>
    <a href="<?php echo e(route('marketingGroups.edit', 1)); ?>" class="btn btn-info" role="button">Edit</a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Delete Seller')): ?>
    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

    <?php endif; ?>
    <?php echo Form::close(); ?>

<br/>
    <div class="table-responsive">
      <table class="table table-bordered table-striped">

          <thead>
              <tr>
                <th>No</th>
                <th>Employee</th>
                <th>Position</th>
                <th>Last Modified</th>
                <th>Operations</th>
              </tr>
          </thead>

          <tbody>
              <?php ($i = 0); ?>
              <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php ($i++); ?>
              <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($seller->name); ?></td>
                <td><?php echo e($seller->position); ?></td>
                <td><?php echo e(date('d m Y', strtotime($seller->created_at))); ?></td>
                <td>
                <a href="<?php echo e(route('userHasSellers.edit', $seller->uhs_id)); ?>" class="btn btn-info pull-left" style="margin-right: 3px;">Edit</a>

                <?php echo Form::open(['method' => 'DELETE', 'route' => ['userHasSellers.destroy', $seller->uhs_id], 'class' => 'delete' ]); ?>

                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                <?php echo Form::close(); ?>


                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
    </div>
    <a href="<?php echo e(URL::to('userHasSellers/create/'.$idm)); ?>" class="btn btn-success">Add Seller</a>
        
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>