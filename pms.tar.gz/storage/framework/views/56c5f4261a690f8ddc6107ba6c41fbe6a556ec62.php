

<?php $__env->startSection('title', '| Edit Position'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>

    <h1><i class='fa fa-user-plus'></i> Edit <?php echo e($position->name); ?></h1>
    <hr>

    <?php echo e(Form::model($position, array('route' => array('positions.update', $position->id), 'method' => 'PUT'))); ?>

    <div class="form-group">
      <?php echo e(Form::label('position', 'Position')); ?>

      <?php echo e(Form::text('position', null, ['class' => 'form-control', 'placeholder' => 'Enter Position'])); ?>

    </div>
    <?php echo e(Form::submit('Save', array('class' => 'btn btn-primary'))); ?>

    <?php echo e(Form::close()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>