<h2>Sales</h2>
  <div class="table-responsive">
    <table class="table table-bordered table-striped" style="background-color: #f2f2f2;">
        <thead>
            <tr style="background-color: #e6e6e6;">
                <th>Team</th>
                <th>January</th>
                <th>February</th>
                <th>March</th>
                <th>April</th>
                <th>May</th>
                <th>June</th>
                <th>July</th>
                <th>August</th>
                <th>September</th>
                <th>October</th>
                <th>November</th>
                <th>December</th>
                <th>Total</th>
            </tr>
        </thead>

        <tbody>
          <?php
            $places = array(
              array('place' => 'KIARACONDONG'),
              array('place' => 'KOPO'),
              array('place' => 'LEMBANG'),
              //array('place' => 'SOREANG'),
            );
              $mvars = array(
                  'jan' => array('month' => 1, 'tot' => 0), 'feb' => array('month' => 2, 'tot' => 0), 'mar' => array('month' => 3, 'tot' => 0),
                  'apr' => array('month' => 4, 'tot' => 0), 'mei' => array('month' => 5, 'tot' => 0), 'jun' => array('month' => 6, 'tot' => 0),
                  'jul' => array('month' => 7, 'tot' => 0), 'aug' => array('month' => 8, 'tot' => 0), 'sep' => array('month' => 9, 'tot' => 0),
                  'oct' => array('month' => 10, 'tot' => 0), 'nov' => array('month' => 11, 'tot' => 0), 'dec' => array('month' => 12, 'tot' => 0),
              );
              $msstot = 0;
          ?>
            <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($pvars = array(
                'jan' => array('month' => 1, 'tot' => 0), 'feb' => array('month' => 2, 'tot' => 0), 'mar' => array('month' => 3, 'tot' => 0),
                'apr' => array('month' => 4, 'tot' => 0), 'mei' => array('month' => 5, 'tot' => 0), 'jun' => array('month' => 6, 'tot' => 0),
                'jul' => array('month' => 7, 'tot' => 0), 'aug' => array('month' => 8, 'tot' => 0), 'sep' => array('month' => 9, 'tot' => 0),
                'oct' => array('month' => 10, 'tot' => 0), 'nov' => array('month' => 11, 'tot' => 0), 'dec' => array('month' => 12, 'tot' => 0),
            )); ?>
            <?php ($psstot = 0); ?>
              <tr style="font-weight: bold; background-color: #e6e6e6;">
                <td colspan = "14" align="center"><?php echo e($place['place']); ?></td>
              </tr>

              <?php $__currentLoopData = $marketings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($place['place'] == $marketing->place): ?>
                  <tr>

                    <td style="font-weight: bold;"><?php echo e($marketing->name); ?></td>
                    <?php
                        $vars = array(
                            'jan' => array('month' => 1, 'tot' => 0), 'feb' => array('month' => 2, 'tot' => 0), 'mar' => array('month' => 3, 'tot' => 0),
                            'apr' => array('month' => 4, 'tot' => 0), 'mei' => array('month' => 5, 'tot' => 0), 'jun' => array('month' => 6, 'tot' => 0),
                            'jul' => array('month' => 7, 'tot' => 0), 'aug' => array('month' => 8, 'tot' => 0), 'sep' => array('month' => 9, 'tot' => 0),
                            'oct' => array('month' => 10, 'tot' => 0), 'nov' => array('month' => 11, 'tot' => 0), 'dec' => array('month' => 12, 'tot' => 0),
                        );
                    ?>
                    <?php ($sstot = 0); ?>
                    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($sale->id == $marketing->id): ?>
                        <?php if($sale->m == 1): ?>
                          <?php ($vars['jan']['tot'] = $sale->tot); ?>
                          <?php ($mvars['jan']['tot'] += $sale->tot); ?>
                          <?php ($pvars['jan']['tot'] += $sale->tot); ?>
                        <?php elseif($sale->m == 2): ?>
                          <?php ($vars['feb']['tot'] = $sale->tot); ?>
                          <?php ($mvars['feb']['tot'] += $sale->tot); ?>
                          <?php ($pvars['feb']['tot'] += $sale->tot); ?>
                        <?php elseif($sale->m == 3): ?>
                          <?php ($vars['mar']['tot'] = $sale->tot); ?>
                          <?php ($mvars['mar']['tot'] += $sale->tot); ?>
                          <?php ($pvars['mar']['tot'] += $sale->tot); ?>
                        <?php elseif($sale->m == 4): ?>
                          <?php ($vars['apr']['tot'] = $sale->tot); ?>
                          <?php ($mvars['apr']['tot'] += $sale->tot); ?>
                          <?php ($pvars['apr']['tot'] += $sale->tot); ?>
                        <?php elseif($sale->m == 5): ?>
                          <?php ($vars['mei']['tot'] = $sale->tot); ?>
                          <?php ($mvars['mei']['tot'] += $sale->tot); ?>
                          <?php ($pvars['mei']['tot'] += $sale->tot); ?>
                        <?php elseif($sale->m == 6): ?>
                          <?php ($vars['jun']['tot'] = $sale->tot); ?>
                          <?php ($mvars['jun']['tot'] += $sale->tot); ?>
                          <?php ($pvars['jun']['tot'] += $sale->tot); ?>
                        <?php elseif($sale->m == 7): ?>
                          <?php ($vars['jul']['tot'] = $sale->tot); ?>
                          <?php ($mvars['jul']['tot'] += $sale->tot); ?>
                          <?php ($pvars['jul']['tot'] += $sale->tot); ?>
                        <?php elseif($sale->m == 8): ?>
                          <?php ($vars['aug']['tot'] = $sale->tot); ?>
                          <?php ($mvars['aug']['tot'] += $sale->tot); ?>
                          <?php ($pvars['aug']['tot'] += $sale->tot); ?>
                        <?php elseif($sale->m == 9): ?>
                          <?php ($vars['sep']['tot'] = $sale->tot); ?>
                          <?php ($mvars['sep']['tot'] += $sale->tot); ?>
                          <?php ($pvars['sep']['tot'] += $sale->tot); ?>
                        <?php elseif($sale->m == 10): ?>
                          <?php ($vars['oct']['tot'] = $sale->tot); ?>
                          <?php ($mvars['oct']['tot'] += $sale->tot); ?>
                          <?php ($pvars['oct']['tot'] += $sale->tot); ?>
                        <?php elseif($sale->m == 11): ?>
                          <?php ($vars['nov']['tot'] = $sale->tot); ?>
                          <?php ($mvars['nov']['tot'] += $sale->tot); ?>
                          <?php ($pvars['nov']['tot'] += $sale->tot); ?>
                        <?php elseif($sale->m == 11): ?>
                          <?php ($vars['dec']['tot'] = $sale->tot); ?>
                          <?php ($mvars['dec']['tot'] += $sale->tot); ?>
                          <?php ($pvars['dec']['tot'] += $sale->tot); ?>
                        <?php endif; ?>
                        <?php ($sstot += $sale->tot); ?>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php ($msstot += $sstot); ?>
                    <?php ($psstot += $sstot); ?>
                    <td><?php echo e($vars['jan']['tot']); ?></td><td><?php echo e($vars['feb']['tot']); ?></td><td><?php echo e($vars['mar']['tot']); ?></td><td><?php echo e($vars['apr']['tot']); ?></td>
                    <td><?php echo e($vars['mei']['tot']); ?></td><td><?php echo e($vars['jun']['tot']); ?></td><td><?php echo e($vars['jul']['tot']); ?></td><td><?php echo e($vars['aug']['tot']); ?></td>
                    <td><?php echo e($vars['sep']['tot']); ?></td><td><?php echo e($vars['oct']['tot']); ?></td><td><?php echo e($vars['nov']['tot']); ?></td><td><?php echo e($vars['dec']['tot']); ?></td>
                    <td style="font-weight: bold;"><?php echo e($sstot); ?></td>
                  </tr>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <tr style="font-weight: bold;">
                <td>TOTAL</td>
                <td><?php echo e($pvars['jan']['tot']); ?></td><td><?php echo e($pvars['feb']['tot']); ?></td><td><?php echo e($pvars['mar']['tot']); ?></td><td><?php echo e($pvars['apr']['tot']); ?></td>
                <td><?php echo e($pvars['mei']['tot']); ?></td><td><?php echo e($pvars['jun']['tot']); ?></td><td><?php echo e($pvars['jul']['tot']); ?></td><td><?php echo e($pvars['aug']['tot']); ?></td>
                <td><?php echo e($pvars['sep']['tot']); ?></td><td><?php echo e($pvars['oct']['tot']); ?></td><td><?php echo e($pvars['nov']['tot']); ?></td><td><?php echo e($mvars['dec']['tot']); ?></td>
                <td><?php echo e($psstot); ?></td>
              </tr>
              <tr>
                <td colspan="14">&nbsp;</td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr style="font-weight: bold;">
              <td>GRANT TOTAL</td>
              <td><?php echo e($mvars['jan']['tot']); ?></td><td><?php echo e($mvars['feb']['tot']); ?></td><td><?php echo e($mvars['mar']['tot']); ?></td><td><?php echo e($mvars['apr']['tot']); ?></td>
              <td><?php echo e($mvars['mei']['tot']); ?></td><td><?php echo e($mvars['jun']['tot']); ?></td><td><?php echo e($mvars['jul']['tot']); ?></td><td><?php echo e($mvars['aug']['tot']); ?></td>
              <td><?php echo e($mvars['sep']['tot']); ?></td><td><?php echo e($mvars['oct']['tot']); ?></td><td><?php echo e($mvars['nov']['tot']); ?></td><td><?php echo e($mvars['dec']['tot']); ?></td>
              <td><?php echo e($msstot); ?></td>
            </tr>
        </tbody>
    </table>
  </div>
