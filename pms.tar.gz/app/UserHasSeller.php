<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserHasSeller extends Model
{
    //
}
